"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var Direction;
(function (Direction) {
    Direction[Direction["UNKNOWN"] = 0] = "UNKNOWN";
    Direction[Direction["NEXT"] = 1] = "NEXT";
    Direction[Direction["PREV"] = 2] = "PREV";
})(Direction = exports.Direction || (exports.Direction = {}));
var Carousel = (function () {
    //@Input() public noPause:boolean;
    //@Input() public noTransition:boolean;
    function Carousel() {
        // @Input() public get interval():number {
        //   return this._interval;
        // }
        // public set interval(value:number) {
        //   this._interval = value;
        //   this.restartTimer();
        // }
        this.slides = [];
        this.currentInterval = null;
        this.destroyed = false;
    }
    //private _interval:number;
    Carousel.prototype.ngOnDestroy = function () {
        this.destroyed = true;
    };
    Carousel.prototype.select = function (nextSlide, direction) {
        if (direction === void 0) { direction = Direction.UNKNOWN; }
        var nextIndex = nextSlide.index;
        if (direction === Direction.UNKNOWN) {
            direction = nextIndex > this.getCurrentIndex() ? Direction.NEXT : Direction.PREV;
        }
        // Prevent this user-triggered transition from occurring if there is already one in progress
        if (nextSlide && nextSlide !== this.currentSlide) {
            this.goNext(nextSlide, direction);
        }
    };
    Carousel.prototype.goNext = function (slide, direction) {
        if (this.destroyed) {
            return;
        }
        slide.direction = direction;
        slide.active = true;
        if (this.currentSlide) {
            this.currentSlide.direction = direction;
            this.currentSlide.active = false;
        }
        this.currentSlide = slide;
        // every time you change slides, reset the timer
        // this.restartTimer();
    };
    Carousel.prototype.getSlideByIndex = function (index) {
        var len = this.slides.length;
        for (var i = 0; i < len; ++i) {
            if (this.slides[i].index === index) {
                return this.slides[i];
            }
        }
    };
    Carousel.prototype.getCurrentIndex = function () {
        return !this.currentSlide ? 0 : this.currentSlide.index;
    };
    Carousel.prototype.next = function () {
        var newIndex = (this.getCurrentIndex() + 1) % this.slides.length;
        if (newIndex === 0 && this.noWrap) {
            this.pause();
            return;
        }
        return this.select(this.getSlideByIndex(newIndex), Direction.NEXT);
    };
    Carousel.prototype.prev = function () {
        var newIndex = this.getCurrentIndex() - 1 < 0 ? this.slides.length - 1 : this.getCurrentIndex() - 1;
        if (this.noWrap && newIndex === this.slides.length - 1) {
            this.pause();
            return;
        }
        return this.select(this.getSlideByIndex(newIndex), Direction.PREV);
    };
    // private restartTimer() {
    //   this.resetTimer();
    //   let interval = +this.interval;
    //   if (!isNaN(interval) && interval > 0) {
    //     this.currentInterval = setInterval(() => {
    //       let nInterval = +this.interval;
    //       if (this.isPlaying && !isNaN(this.interval) && nInterval > 0 && this.slides.length) {
    //         this.next();
    //       } else {
    //         this.pause();
    //       }
    //     }, interval);
    //   }
    // }
    Carousel.prototype.resetTimer = function () {
        if (this.currentInterval) {
            clearInterval(this.currentInterval);
            this.currentInterval = null;
        }
    };
    //
    // public play() {
    //   if (!this.isPlaying) {
    //     this.isPlaying = true;
    //     this.restartTimer();
    //   }
    // }
    Carousel.prototype.pause = function () {
        //if (!this.noPause) {
        this.isPlaying = false;
        this.resetTimer();
        //}
    };
    Carousel.prototype.addSlide = function (slide) {
        slide.index = this.slides.length;
        this.slides.push(slide);
        if (this.slides.length === 1 || slide.active) {
            this.select(this.slides[this.slides.length - 1]);
            if (this.slides.length === 1) {
                //this.play();
                this.pause();
            }
        }
        else {
            slide.active = false;
        }
    };
    return Carousel;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], Carousel.prototype, "noWrap", void 0);
Carousel = __decorate([
    core_1.Component({
        selector: 'carousel',
        template: "\n    <div class=\"carousel slide\">\n      <!--<ol class=\"carousel-indicators\" [hidden]=\"slides.length <= 1\">-->\n         <!--<li style=\"background-color: #00ab6b\" *ngFor=\"let slidez of slides\" [class.active]=\"slidez.active === true\" (click)=\"select(slidez)\"></li>-->\n      <!--</ol>-->\n      <div class=\"carousel-inner\"><ng-content></ng-content></div>\n                  <a class=\"left carousel-control\" (click)=\"prev()\" [hidden]=\"!slides.length\">\n                    <i class=\"fa fa-arrow-left\" aria-hidden=\"true\"></i>\n                  </a>\n                  <a class=\"right carousel-control\" (click)=\"next()\" [hidden]=\"!slides.length\">\n                    <i class=\"fa fa-arrow-right\" aria-hidden=\"true\"></i>\n                 </a>\n    </div>\n  "
    }),
    __metadata("design:paramtypes", [])
], Carousel);
exports.Carousel = Carousel;
//# sourceMappingURL=carousel.component.js.map