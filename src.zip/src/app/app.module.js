"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
var app_component_1 = require("./app.component");
var select_directive_1 = require("./select.directive");
var app_design_email_template_component_1 = require("./app-design-email-template.component");
var discountCouponList_component_1 = require("./discountCouponList.component");
var angular_froala_wysiwyg_1 = require("angular-froala-wysiwyg");
var ngx_bootstrap_1 = require("ngx-bootstrap");
var discountCoupon_service_1 = require("./discountCoupon.service");
var angular2_color_picker_1 = require("angular2-color-picker");
var emailTemplate_service_1 = require("./emailTemplate.service");
var tagsInput_directive_1 = require("./tagsInput.directive");
// import {Slide} from './slide.component';
// import {Carousel} from './carousel.component';
// import { NgUploaderModule } from 'ngx-uploader';
// import {PageSliderModule}    from 'ng2-page-slider';
// import {ComplibImageCropComponent} from './complib-image-crop.component';
// import { ImageCropperComponent, CropperSettings, Bounds } from 'ng2-img-cropper';
// import { DndModule } from 'ng2-dnd';
// import { CKEditorModule } from 'ng2-ckeditor';
// import { TrumbowygModule} from 'ng2-lazy-trumbowyg';
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [angular_froala_wysiwyg_1.FroalaEditorModule.forRoot(), angular_froala_wysiwyg_1.FroalaViewModule.forRoot(), platform_browser_1.BrowserModule, forms_1.FormsModule, angular2_color_picker_1.ColorPickerModule, http_1.HttpModule, ngx_bootstrap_1.ModalModule.forRoot()],
        declarations: [app_component_1.AppComponent, app_design_email_template_component_1.DesignEmailTemplateComponent, select_directive_1.SelectDirective, discountCouponList_component_1.DiscountCouponListComponent, tagsInput_directive_1.TagsInputDirective],
        providers: [emailTemplate_service_1.EmailTemplateService, discountCoupon_service_1.GetDiscountCouponService],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map