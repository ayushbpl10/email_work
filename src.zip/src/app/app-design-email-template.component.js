"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
require("rxjs/Rx");
var DesignEmailTemplateComponent = (function () {
    function DesignEmailTemplateComponent(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
        this.TemplateEmail = '';
        this.TemplateSave = new core_1.EventEmitter();
        this.TemplateWithEmail = new core_1.EventEmitter();
        this.DiscountCouponCreate = new core_1.EventEmitter();
        this.options = {
            charCounterCount: true,
            toolbarButtons: ['bold', 'italic', 'underline', 'paragraphFormat', 'Smarty Tags', 'html', 'insertLink'],
            toolbarButtonsXS: ['bold', 'italic', 'underline', 'paragraphFormat', 'Smarty Tags', 'html', 'insertLink'],
            toolbarButtonsSM: ['bold', 'italic', 'underline', 'paragraphFormat', 'Smarty Tags', 'html', 'insertLink'],
            toolbarButtonsMD: ['bold', 'italic', 'underline', 'paragraphFormat', 'Smarty Tags', 'html', 'insertLink'],
            linkEditButtons: [],
            heightMin: 100,
            heightMax: 150
        };
        this.initialtext = true;
        this.showtext = false;
        this.showimage = false;
        this.showbutton = false;
        this.showimagetext = false;
        this.showimageimage = false;
        this.showdiscountcoupon = false;
        this.discountEdit = false;
        this.customDiscountImgURL = 'http://';
        this.category = '1';
        this.dataEmailArray = '';
        this.anniversary_category = true;
        this.birthday_category = false;
        this.christmas_category = false;
    }
    Object.defineProperty(DesignEmailTemplateComponent.prototype, "NewCouponCreated", {
        set: function (NewCouponCreated) {
            this.CouponCreated(NewCouponCreated);
        },
        enumerable: true,
        configurable: true
    });
    ;
    DesignEmailTemplateComponent.prototype.EmailPreview = function () {
        var template = jQuery('#email').parent().html();
        var desktop = jQuery('#desktopPreview');
        desktop.attr('srcdoc', template);
        desktop.on('load', function () {
            desktop.contents().find('#email').removeAttr('id');
            desktop.contents().find('.hoverable').removeClass('hoverable');
            desktop.contents().find('.hover-btn').remove();
            desktop.contents().find('a').attr('target', '_blank');
        });
        var phone = jQuery('#frame_1');
        phone.attr('srcdoc', template);
        phone.on('load', function () {
            phone.contents().find('#email').removeAttr('id');
            phone.contents().find('.hoverable').removeClass('hoverable');
            phone.contents().find('.hover-btn').remove();
            phone.contents().find('a').attr('target', '_blank');
        });
    };
    DesignEmailTemplateComponent.prototype.Save = function () {
        jQuery('#destination').find('a').removeAttr('disabled');
        jQuery('#destination').find('.hover-btn').remove();
        var template = jQuery('#email').parent().html();
        this.TemplateSave.emit(template);
        var editoptions = jQuery('.hover-btn').first().clone(false);
        jQuery('#destination').find('[data-initial="false"]').append(editoptions);
    };
    DesignEmailTemplateComponent.prototype.ImageModalTrigger = function (imageFrom, event) {
        this.imgFrom = imageFrom;
        jQuery(event.target).attr('data-toggle', 'modal').attr('data-target', '#imageModal');
    };
    DesignEmailTemplateComponent.prototype.BrowseImage = function () {
        jQuery('#imageModal').modal('toggle');
    };
    DesignEmailTemplateComponent.prototype.onAddClick = function () {
        var self = this;
        var src = jQuery('#add_input').val();
        if (self.imgFrom === 'left') {
            jQuery(self.element).find('img[data-from="left"]').attr('src', src).css('width', '100%').siblings().remove();
            jQuery('#preview_image_left').find('img').attr('src', src);
        }
        else if (self.imgFrom === 'right') {
            jQuery(self.element).find('img[data-from="right"]').attr('src', src).css('width', '100%').siblings().remove();
            jQuery('#preview_image_right').find('img').attr('src', src);
        }
        else if (self.imgFrom === 'withtext') {
            jQuery(self.element).find('img[data-from="one"]').attr('src', src).css('width', '100%').siblings().remove();
            jQuery('#preview_image_text').find('img').attr('src', src);
        }
        else {
            jQuery(self.element).find('img[data-from="one"]').attr('src', src).css('width', '100%').siblings().remove();
            jQuery('#preview_image').find('img').attr('src', src);
        }
    };
    DesignEmailTemplateComponent.prototype.onImageClick = function (event) {
        var self = this;
        var src = jQuery(event.target).attr('src');
        if (self.imgFrom === 'left') {
            jQuery(self.element).find('img[data-from="left"]').attr('src', src).css('width', '100%').siblings().remove();
            jQuery('#preview_image_left').find('img').attr('src', src);
        }
        else if (self.imgFrom === 'right') {
            jQuery(self.element).find('img[data-from="right"]').attr('src', src).css('width', '100%').siblings().remove();
            jQuery('#preview_image_right').find('img').attr('src', src);
        }
        else {
            var el = jQuery(self.element).find('img[data-from="one"]').attr('src', src).css('width', '100%').siblings().remove();
            var id = el.closest('.item').attr('data-module');
            if (id === 'image_text_item' || id === 'text_image_item') {
                jQuery('#preview_image_text').find('img').attr('src', src);
            }
            else if (id === 'image_item') {
                jQuery('#preview_image').find('img').attr('src', src);
            }
        }
    };
    DesignEmailTemplateComponent.prototype.onImgTitleChange = function (imgfrom, event) {
        jQuery(this.element).find('img').attr('title', event);
    };
    DesignEmailTemplateComponent.prototype.onImgAnchorChange = function (imgfrom, event) {
        this.imgFrom = imgfrom;
        this.Anchorimg = event;
        jQuery(this.element).find('img').closest('a').attr('href', event);
    };
    DesignEmailTemplateComponent.prototype.onImgPosChange = function (imgfrom, event) {
        this.imgFrom = imgfrom;
        if (this.imgFrom === 'left') {
            jQuery(this.element).find('img[data-from="left"]').parent().css('text-align', event).attr('data-align', event);
        }
        else if (this.imgFrom === 'right') {
            jQuery(this.element).find('img[data-from="right"]').parent().css('text-align', event).attr('data-align', event);
        }
        else {
            jQuery(this.element).find('img').closest('[data-align]').css('text-align', event).attr('data-align', event);
        }
    };
    DesignEmailTemplateComponent.prototype.onImgSizeChange = function (imgfrom, event) {
        this.imgFrom = imgfrom;
        var el;
        if (this.imgFrom === 'left') {
            this.sizeleft = event;
            el = jQuery(this.element).find('img[data-from="left"]');
        }
        else if (this.imgFrom === 'right') {
            this.sizeright = event;
            el = jQuery(this.element).find('img[data-from="right"]');
        }
        else {
            el = jQuery(this.element).find('img');
        }
        switch (event) {
            case 'fit':
                el.css('width', '100%');
                el.closest('[data-align]').attr('data-size', 'fit');
                break;
            default:
                el.css('width', event);
                el.closest('[data-align]').attr('data-size', event);
                break;
        }
    };
    DesignEmailTemplateComponent.prototype.onImgBoxSizeChange = function (imgfrom, event) {
        this.imgFrom = imgfrom;
        var width = event + '%';
        var siblingwidth = (100 - parseInt(event, 10)).toString() + '%';
        if (this.imgFrom === 'left') {
            var el = jQuery(this.element).find('img[data-from="left"]').parent();
            el.css('width', width);
            el.siblings().css('width', siblingwidth);
            this.onImgSizeChange('left', this.selimgsizeleft);
        }
        else if (this.imgFrom === 'right') {
            jQuery(this.element).find('img[data-from="right"]').parent().css('width', width).siblings().css('width', siblingwidth);
            this.onImgSizeChange('right', this.selimgsizeright);
        }
        else {
            jQuery(this.element).find('img').parent().css('width', width).siblings().css('width', siblingwidth);
            this.onImgSizeChange('null', 'fit');
        }
    };
    DesignEmailTemplateComponent.prototype.onBorderStyleChange = function (event) {
        this.borderstyle = event;
        jQuery(this.element).find('table').css('border-style', event);
    };
    DesignEmailTemplateComponent.prototype.onBorderColorChange = function (event) {
        this.bordercolor = event;
        jQuery(this.element).find('table').css('border-color', event);
    };
    DesignEmailTemplateComponent.prototype.onBorderWidthChange = function (event) {
        this.borderwidth = event;
        jQuery(this.element).find('table').css('border-width', event + 'px');
    };
    DesignEmailTemplateComponent.prototype.onLinkChange = function (event) {
        jQuery(this.element.children).find('a').attr('data-link', event);
        var href = jQuery(this.element.children).find('a').attr('href');
        if (this.linkTo === 'email' && (href.search('subject') === -1)) {
            jQuery(this.element.children).find('a').attr('href', 'mailto:?subject=&body=');
        }
    };
    DesignEmailTemplateComponent.prototype.ngOnInit = function () {
        jQuery(function () {
            jQuery.FroalaEditor.DefineIcon('Smarty Tags', { NAME: 'tag' });
            jQuery.FroalaEditor.RegisterCommand('Smarty Tags', {
                title: 'Smarty Tags',
                type: 'dropdown',
                focus: false,
                undo: false,
                refreshAfterCallback: true,
                options: {
                    '*|_BUSINESS_USERNAME_|': '*|_BUSINESS_USERNAME_|',
                    '*|_BUSINESS_ADDRESS_|*': '*|_BUSINESS_ADDRESS_|*',
                    '*|_BUSINESS_NAME_|*': '*|_BUSINESS_NAME_|*'
                },
                callback: function (cmd, val) {
                    this.html.insert(val);
                },
                refresh: function ($btn) {
                },
                refreshOnShow: function ($btn, $dropdown) {
                }
            });
        });
    };
    DesignEmailTemplateComponent.prototype.ngOnChanges = function (changes) {
        if (changes.TemplateEmail.currentValue === '') {
            console.log('no input in template');
        }
        else {
            jQuery('#email').html(changes.TemplateEmail.currentValue);
            var editoptions = jQuery('.hover-btn').first().clone(false);
            jQuery('[data-initial="false"]').append(editoptions);
        }
    };
    DesignEmailTemplateComponent.prototype.BackgroundColorChange = function (event) {
        this.backgroundcolor = event;
        if (jQuery(this.element).attr('data-module') === 'discount_item') {
            jQuery(this.element).find('table[data-coupon="true"]').css('background-color', event);
        }
        else {
            jQuery(this.element).children().css('background-color', event);
        }
    };
    DesignEmailTemplateComponent.prototype.TextColorChange = function (event) {
        this.textcolor = event;
        if (jQuery(this.element).attr('data-module') === 'discount_item') {
            jQuery(this.element).find('table[data-coupon="true"]').css('color', event);
        }
        else {
            jQuery(this.element).find('[data-type="text"]').css('color', event);
        }
    };
    DesignEmailTemplateComponent.prototype.LinkColorChange = function (event) {
        this.linkcolor = event;
        if (jQuery(this.element).find('[data-type="text"]').find('a') === 'undefined') {
        }
        else {
            jQuery(this.element).find('[data-type="text"]').find('a').css('color', event);
        }
    };
    DesignEmailTemplateComponent.prototype.BtnBgColorChange = function (event) {
        this.btnbackgroundcolor = event;
        if (jQuery(this.element).attr('data-module') === 'discount_item') {
            jQuery(this.element).find('#discountCouponBtn').css('background-color', event);
        }
        else {
            jQuery(this.element).find('a button').css('background-color', event);
        }
    };
    DesignEmailTemplateComponent.prototype.BtnTextColorChange = function (event) {
        if (jQuery(this.element).attr('data-module') === 'discount_item') {
            jQuery(this.element).find('#discountCouponBtn').css('color', event);
        }
        else {
            this.textcolor = event;
            jQuery(this.element).find('a button').css('color', event);
        }
    };
    DesignEmailTemplateComponent.prototype.onBtnTextChange = function (event) {
        jQuery(this.element).find('a button').html(event);
    };
    DesignEmailTemplateComponent.prototype.ModelChange = function (event) {
        var str = event;
        var res = str.replace('<p>', '').replace('</p>', '');
        jQuery(this.element).find('[data-type="text"]')
            .html(res).find('a').css('color', this.linkcolor).css('color', this.textcolor).css('background-color', this.backgroundcolor);
    };
    DesignEmailTemplateComponent.prototype.onWebAddChange = function (event) {
        jQuery(this.element.children).find('a').attr('href', event);
    };
    DesignEmailTemplateComponent.prototype.onEmailAddChange = function (event) {
        var href = jQuery(this.element.children).find('a').attr('href');
        var newhref = href.replace(/mailto:.+subject/, 'mailto:' + event + '?subject');
        jQuery(this.element.children).find('a').attr('href', newhref);
    };
    DesignEmailTemplateComponent.prototype.onMsgSubChange = function (event) {
        var href = jQuery(this.element.children).find('a').attr('href');
        var newhref = href.replace(/subject=.+body/, 'subject=' + event + '&body');
        jQuery(this.element.children).find('a').attr('href', newhref);
    };
    DesignEmailTemplateComponent.prototype.onMsgBodyChange = function (event) {
        var href = jQuery(this.element.children).find('a').attr('href');
        var newhref = href.split('body=');
        jQuery(this.element.children).find('a').attr('href', newhref[0] + 'body=' + event);
    };
    DesignEmailTemplateComponent.prototype.UpdateEmailArray = function (event) {
        this.dataEmailArray = event;
    };
    DesignEmailTemplateComponent.prototype.TestEmails = function () {
        this.EmailArray = this.dataEmailArray;
        jQuery('#destination').find('a').removeAttr('disabled');
        jQuery('#email').find('.hover-btn').remove();
        var template = jQuery('#email').parent().html();
        this.TemplateWithEmail.emit({ email: this.EmailArray, Html: template });
        var editoptions = jQuery('.hover-btn').first().clone(false);
        jQuery('#destination').find('[data-initial="false"]').append(editoptions);
    };
    DesignEmailTemplateComponent.prototype.ColorPickerDisplay = function (event) {
        setTimeout(function () {
            var el = jQuery(event.target).parent().children('color-picker').find('.color-picker');
            el.find('.arrow').hide();
            el.css('position', 'fixed').css('top', '150px').css('left', '-230px').css('z-index', '1');
        }, 0);
    };
    DesignEmailTemplateComponent.prototype.SelectCategory = function (event) {
        switch (this.category) {
            case '1':
                this.anniversary_category = true;
                this.birthday_category = false;
                this.christmas_category = false;
                break;
            case '2':
                this.anniversary_category = false;
                this.birthday_category = true;
                this.christmas_category = false;
                break;
            case '3':
                this.anniversary_category = false;
                this.birthday_category = false;
                this.christmas_category = true;
                break;
        }
    };
    DesignEmailTemplateComponent.prototype.onAttachCoupon = function (discountCoupon) {
        this.discountCoupon = discountCoupon;
        jQuery(this.element).find('[data-coupon="false"]').remove();
        jQuery(this.element).find('[data-coupon="true"]').show();
        this.discountEdit = true;
        this.changeDetectorRef.detectChanges();
        this.DiscountSelectedId = discountCoupon.id;
        if (this.carousel !== undefined) {
            this.carousel.trigger('destroy.owl.carousel');
        }
        var owl = jQuery('.owl-carousel');
        this.carousel = owl;
        owl.owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            items: 1,
            dots: false,
            onInitialized: carouselInitialized
        });
        function carouselInitialized(event) {
            var self = this;
            var imgset = true;
            var DiscountImgSrc = jQuery('table[data-coupon="true"]').find('img').attr('src');
            var imgarray = jQuery('.owl-item').find('img');
            jQuery.each(imgarray, function (index, value) {
                if (DiscountImgSrc === jQuery(value).attr('src')) {
                    self.carousel.trigger('refresh.owl.carousel', ['initialized.owl.carousel', 100]);
                    self.carousel.on('refreshed.owl.carousel', function (e) {
                        self.carousel.trigger('to.owl.carousel', [index, 0]);
                    });
                    imgset = false;
                    return;
                }
            });
            if (imgset && !jQuery('table[data-coupon="true"]').find('img').hasClass('none')) {
                var data_1 = jQuery('#itemforclone').clone();
                self.carousel.trigger('refresh.owl.carousel', ['initialized.owl.carousel', 100]);
                self.carousel.on('refreshed.owl.carousel', function (e) {
                    jQuery(data_1).find('img').attr('src', DiscountImgSrc);
                    self.carousel.trigger('add.owl.carousel', [data_1, 0]);
                    self.carousel.trigger('to.owl.carousel', [0, 0]);
                });
            }
            if (jQuery('table[data-coupon="true"]').find('img').hasClass('none')) {
                jQuery('table[data-coupon="true"]').find('img').removeClass('none');
                var src = jQuery('.owl-item.active').find('img').attr('src');
                jQuery('table[data-coupon="true"]').find('img').attr('src', src);
            }
        }
        owl.on('translated.owl.carousel', function (event) {
            var src = jQuery('.owl-item.active').find('img').attr('src');
            jQuery('table[data-coupon="true"]').find('img').attr('src', src);
        });
    };
    DesignEmailTemplateComponent.prototype.createDiscountCoupon = function () {
        this.DiscountCouponCreate.emit();
    };
    DesignEmailTemplateComponent.prototype.CouponCreated = function (Coupon) {
        jQuery(this.element).find('[data-coupon="false"]').remove();
        jQuery(this.element).find('[data-coupon="true"]').show();
        this.discountEdit = true;
    };
    DesignEmailTemplateComponent.prototype.OnCustomDiscountImgAdd = function () {
        var self = this;
        var btn = jQuery('#customImageUrlAddBtn');
        var url = this.customDiscountImgURL;
        var img = new Image();
        img.onerror = function () {
            alert(url + ' : ' + 'Image does not exist');
            btn.prop('disabled', false).text('Add');
        };
        img.onload = function () {
            var data = jQuery('#itemforclone').clone();
            jQuery(data).find('img').attr('src', url);
            self.carousel.trigger('add.owl.carousel', [data, 0]);
            self.carousel.trigger('to.owl.carousel', [0, 100]);
            btn.prop('disabled', false).text('Add');
            var src = jQuery('.owl-item.active').find('img').attr('src');
            jQuery('table[data-coupon="true"]').find('img').attr('src', src);
        };
        img.src = url;
        btn.prop('disabled', true).text('Loading');
    };
    DesignEmailTemplateComponent.prototype.ngAfterViewInit = function () {
        var self = this;
        function Bootbox(el) {
            bootbox.confirm({
                message: 'Do you want to remove?',
                buttons: {
                    confirm: {
                        label: 'Yes',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'No',
                        className: 'btn-danger'
                    }
                },
                callback: function (result) {
                    if (result === true) {
                        jQuery(el).remove();
                    }
                }
            });
        }
        function TextItem(el, event) {
            if (event.target.id === 'removeitem') {
                Bootbox(el);
            }
            else {
                jQuery('#rightModal').modal('toggle');
                self.initialtext = false;
                self.showtext = true;
                self.showimage = false;
                self.showbutton = false;
                self.showimagetext = false;
                self.showimageimage = false;
                self.showdiscountcoupon = false;
                self.content = jQuery(el).find('[data-type="text"]').html();
                self.element = el;
                self.backgroundcolor = jQuery(el).find('.item_element').css('background-color');
                self.textcolor = jQuery(el).find('.textitem').css('color');
                if (jQuery(el).find('a').css('color') === 'undefined') {
                    self.linkcolor = '#0000EE';
                }
                else {
                    if (jQuery(el).find('a').css('color') === undefined) {
                    }
                    else {
                        self.linkcolor = jQuery(el).find('a').css('color');
                    }
                }
            }
        }
        function ImageItem(el, event) {
            if (event.target.id === 'removeitem') {
                Bootbox(el);
            }
            else {
                jQuery('#rightModal').modal('toggle');
                self.initialtext = false;
                self.showtext = false;
                self.showimage = true;
                self.showbutton = false;
                self.showimagetext = false;
                self.showimageimage = false;
                self.showdiscountcoupon = false;
                self.element = el;
                self.backgroundcolor = jQuery(el).children().css('background-color');
                self.changeDetectorRef.detectChanges();
                var element = jQuery(el).find('img[data-from="one"]');
                var src = element.attr('src');
                var tooltip = element.attr('title');
                jQuery('#preview_image').find('img').attr('src', src);
                var imgPos = element.closest('div[data-align]').attr('data-align');
                var imgSize = element.closest('div[data-align]').attr('data-size');
                var imgHref = element.closest('a[href]').attr('href');
                self.Titleimg = tooltip;
                self.Anchorimg = imgHref;
                self.selimgpos = imgPos;
                self.imgFrom = 'null';
                self.selimgsize = imgSize;
            }
        }
        function ButtonItem(el, event) {
            if (event.target.id === 'removeitem') {
                Bootbox(el);
            }
            else {
                jQuery('#rightModal').modal('toggle');
                self.initialtext = false;
                self.showtext = false;
                self.showimage = false;
                self.showbutton = true;
                self.showimagetext = false;
                self.showimageimage = false;
                self.showdiscountcoupon = false;
                self.element = el;
                jQuery(el).find('a.anchorbtn').click(function (e) {
                    e.preventDefault();
                    return false;
                });
                var ele = jQuery(el).children();
                self.backgroundcolor = ele.css('background-color');
                self.btnbackgroundcolor = ele.find('a button').css('background-color');
                self.textcolor = ele.find('a button').css('color');
                self.buttontext = ele.find('a button').html();
                self.linkTo = ele.find('a').attr('data-link');
                var href = ele.find('a').attr('href');
                if (self.linkTo === 'web' && href === '#') {
                    self.webAdd = 'http://';
                    self.emailAdd = '';
                    self.emailSub = '';
                    self.emailBody = '';
                }
                else if (self.linkTo === 'web' && href !== '#' && (href.search('subject') === -1)) {
                    self.webAdd = href;
                    self.emailAdd = '';
                    self.emailSub = '';
                    self.emailBody = '';
                }
                else if (self.linkTo === 'email' && href === '#') {
                    self.webAdd = 'http://';
                    self.emailAdd = '';
                    self.emailSub = '';
                    self.emailBody = '';
                }
                else {
                    self.webAdd = 'http://';
                    self.emailAdd = href.substring(href.indexOf(':') + 1, href.indexOf('?'));
                    self.emailSub = href.substring(href.indexOf('subject=') + 8, href.indexOf('&'));
                    self.emailBody = href.substring(href.indexOf('body=') + 5);
                }
            }
        }
        function ImageTextItem(el, event) {
            if (event.target.id === 'removeitem') {
                Bootbox(el);
            }
            else {
                jQuery('#rightModal').modal('toggle');
                self.initialtext = false;
                self.showtext = false;
                self.showimage = false;
                self.showbutton = false;
                self.showimagetext = true;
                self.showimageimage = false;
                self.showdiscountcoupon = false;
                var elem = jQuery(el).find('[data-type="text"]');
                self.content = elem.html();
                self.element = jQuery(el);
                self.backgroundcolor = jQuery(el).children().css('background-color');
                self.textcolor = elem.css('color');
                if (elem.find('a').css('color') === 'undefined') {
                    self.linkcolor = '#0000EE';
                }
                else {
                    self.linkcolor = elem.find('a').css('color');
                }
                self.changeDetectorRef.detectChanges();
                var src = jQuery(el).find('img[data-from="one"]').attr('src');
                jQuery('#preview_image_text').find('img').attr('src', src);
                var imgPos = jQuery(el).find('img').parent().attr('data-align');
                var imgSize = jQuery(el).find('img').parent().attr('data-size');
                self.selimgpos = imgPos;
                self.selimgsize = imgSize;
                var element = jQuery(el).find('img[data-from="one"]');
                var widthper = element.parent().width() / element.parent().parent().width() * 100;
                self.selimgboxsize = Math.round(widthper).toString();
                self.imgFrom = 'withtext';
            }
        }
        function ImageImageItem(el, event) {
            if (event.target.id === 'removeitem') {
                Bootbox(el);
            }
            else {
                jQuery('#rightModal').modal('toggle');
                self.initialtext = false;
                self.showtext = false;
                self.showimage = false;
                self.showbutton = false;
                self.showimagetext = false;
                self.showimageimage = true;
                self.showdiscountcoupon = false;
                self.element = jQuery(el);
                self.backgroundcolor = jQuery(el).children().css('background-color');
                self.changeDetectorRef.detectChanges();
                var eleleft = jQuery(el).find('img[data-from="left"]');
                var srcleft = eleleft.attr('src');
                jQuery('#preview_image_left').find('img').attr('src', srcleft);
                var imgPosleft = eleleft.parent().attr('data-align');
                var imgSizeleft = eleleft.parent().attr('data-size');
                self.selimgposleft = imgPosleft;
                self.selimgsizeleft = imgSizeleft;
                var widthperleft = eleleft.parent().width() / eleleft.parent().parent().width() * 100;
                self.selimgboxsizeleft = Math.round(widthperleft).toString();
                var eleright = jQuery(el).find('img[data-from="right"]');
                var srcright = eleright.attr('src');
                jQuery('#preview_image_right').find('img').attr('src', srcright);
                var imgPosright = eleright.parent().attr('data-align');
                var imgSizeright = eleright.parent().attr('data-size');
                self.selimgposright = imgPosright;
                self.selimgsizeright = imgSizeright;
                var widthperright = eleright.parent().width() / eleright.parent().parent().width() * 100;
                self.selimgboxsizeright = Math.round(widthperright).toString();
            }
        }
        function DiscountItem(el, event) {
            if (event.target.id === 'removeitem') {
                bootbox.confirm({
                    message: 'Do you want to remove?',
                    buttons: {
                        confirm: {
                            label: 'Yes',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if (result === true) {
                            jQuery(el).remove();
                            jQuery('[data-module="discount_item"]').find('[data-initial="true"]').show();
                            self.discountEdit = false;
                        }
                    }
                });
            }
            else {
                jQuery('#rightModal').modal('toggle');
                self.initialtext = false;
                self.showtext = false;
                self.showimage = false;
                self.showbutton = false;
                self.showimagetext = false;
                self.showimageimage = false;
                self.showdiscountcoupon = true;
                self.element = jQuery(el);
                if (jQuery(el).find('[data-coupon="true"]').is(':hidden')) {
                    self.discountEdit = false;
                    self.changeDetectorRef.detectChanges();
                }
                else {
                    self.onAttachCoupon(self.discountCoupon);
                }
                var table = jQuery(el).find('table');
                self.backgroundcolor = table.css('background-color');
                self.bordercolor = table.css('border-color');
                self.borderstyle = table.css('border-style');
                var border_width = table.css('border-width');
                self.borderwidth = border_width.replace('px', '');
                self.textcolor = table.css('color');
                self.btnbackgroundcolor = table.find('#discountCouponBtn').css('background-color');
                self.btntextcolor = table.find('#discountCouponBtn').css('color');
            }
        }
        jQuery('#destination').find('[data-module]').addClass('indestination');
        jQuery('[data-module="text_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            TextItem(this, event);
        });
        jQuery('[data-module="image_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            ImageItem(this, event);
        });
        jQuery('[data-module="button_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            ButtonItem(this, event);
        });
        jQuery('[data-module="image_text_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            ImageTextItem(this, event);
        });
        jQuery('[data-module="text_image_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            ImageTextItem(this, event);
        });
        jQuery('[data-module="image_image_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            ImageImageItem(this, event);
        });
        jQuery('#destination').find('[data-module="discount_item"]:not(:has([data-initial="true"]))').on('click', function (event) {
            DiscountItem(this, event);
        });
        var editoptions = jQuery('.hover-btn').first().clone(false);
        jQuery('[data-initial="false"]').append(editoptions);
        jQuery('.anchorbtn').click(function (e) {
            e.preventDefault();
        });
        jQuery('.anchorimg').click(function (e) {
            e.preventDefault();
        });
        jQuery('#origin').find('[data-initial="false"]').hide();
        jQuery('#destination').sortable({
            revert: true,
            placeholder: 'ui-state-highlight'
        });
        jQuery('#destination').disableSelection();
        jQuery('#origin .item').draggable({
            connectToSortable: '#destination',
            helper: 'clone',
            revert: 'invalid'
        });
        jQuery('#destination').droppable({
            drop: function (event, ui) {
                var el = jQuery(ui.helper[0]);
                Drop(el);
            }
        });
        function Drop(el) {
            el.find('[data-initial="false"]').show();
            if (el.find('[data-coupon="false"]').length > 0) {
                el.find('[data-coupon="true"]').hide();
            }
            el.find('[data-initial="true"]').remove();
            el.removeClass('col-sm-6 justify-content-center');
            el.css('width', '100%');
            el.css('height', 'auto');
            if (el.hasClass('indestination')) {
                return;
            }
            else {
                el.addClass('indestination');
            }
            var id = el.attr('data-module');
            switch (id) {
                case 'text_item':
                    el.on('click', function (event) {
                        TextItem(el, event);
                    });
                    break;
                case 'image_item':
                    el.on('click', function (event) {
                        ImageItem(el, event);
                    });
                    break;
                case 'button_item':
                    el.on('click', function (event) {
                        ButtonItem(el, event);
                    });
                    break;
                case 'image_text_item':
                case 'text_image_item':
                    el.on('click', function (event) {
                        ImageTextItem(el, event);
                    });
                    break;
                case 'image_image_item':
                    el.on('click', function (event) {
                        ImageImageItem(el, event);
                    });
                    break;
                case 'discount_item':
                    var dropped = jQuery('#destination').find('[data-module="discount_item"]').length;
                    if (dropped > 0) {
                        jQuery('[data-module="discount_item"]').find('[data-initial="true"]').hide();
                    }
                    el.on('click', function (event) {
                        DiscountItem(el, event);
                    });
                    break;
                default:
                    break;
            }
        }
        var phone = jQuery('#phone_1');
        var iframe = jQuery('#frame_1');
        jQuery(phone).css('width', '375px').css('height', '667px');
        jQuery('#phones').on('click', function (evt) {
            var width;
            var height;
            if (evt.target.value === '1') {
                width = 375;
                height = 667;
            }
            if (evt.target.value === '2') {
                width = 400;
                height = 640;
            }
            if (evt.target.value === '3') {
                width = 320;
                height = 480;
            }
            if (evt.target.value === '4') {
                width = 360;
                height = 640;
            }
            if (evt.target.value === '5') {
                width = 768;
                height = 1024;
            }
            jQuery(phone).css('width', width + 'px');
            jQuery(phone).css('height', height + 'px');
        });
        jQuery(iframe).on('onload', function () {
            afterLoading();
        });
        function afterLoading() {
            jQuery(phone).addClass('phone view_1');
        }
    };
    return DesignEmailTemplateComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], DesignEmailTemplateComponent.prototype, "NewCouponCreated", null);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], DesignEmailTemplateComponent.prototype, "DiscountSelectedId", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], DesignEmailTemplateComponent.prototype, "TemplateEmail", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], DesignEmailTemplateComponent.prototype, "TemplateID", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], DesignEmailTemplateComponent.prototype, "TemplateSave", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], DesignEmailTemplateComponent.prototype, "TemplateWithEmail", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], DesignEmailTemplateComponent.prototype, "DiscountCouponCreate", void 0);
DesignEmailTemplateComponent = __decorate([
    core_1.Component({
        selector: 'app-design-email-template',
        templateUrl: "./app-design-email-template.component.html"
    }),
    __metadata("design:paramtypes", [core_1.ChangeDetectorRef])
], DesignEmailTemplateComponent);
exports.DesignEmailTemplateComponent = DesignEmailTemplateComponent;
//# sourceMappingURL=app-design-email-template.component.js.map