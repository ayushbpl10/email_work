"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var ng2_img_cropper_1 = require("ng2-img-cropper");
var ngx_bootstrap_1 = require("ngx-bootstrap");
var URL = '../img/';
var ComplibImageCropComponent = (function () {
    function ComplibImageCropComponent() {
        this.sendImage = new core_1.EventEmitter();
        this.showPopup = false;
        this.onClose = new core_1.EventEmitter();
        this.cropperSettings1 = new ng2_img_cropper_1.CropperSettings();
        this.cropperSettings1.width = 200;
        this.cropperSettings1.height = 200;
        this.cropperSettings1.croppedWidth = 200;
        this.cropperSettings1.croppedHeight = 200;
        this.cropperSettings1.canvasWidth = 500;
        this.cropperSettings1.canvasHeight = 300;
        this.cropperSettings1.minWidth = 10;
        this.cropperSettings1.minHeight = 10;
        this.cropperSettings1.rounded = true;
        this.cropperSettings1.keepAspect = true;
        this.cropperSettings1.cropperDrawSettings.strokeColor = '#333';
        this.cropperSettings1.cropperDrawSettings.strokeWidth = 2;
        this.data1 = {};
    }
    ComplibImageCropComponent.prototype.ngOnChanges = function (changes) {
        if (changes['showPopup'] != undefined) {
            if (this.showPopup == true) {
                this.show();
            }
        }
    };
    ComplibImageCropComponent.prototype.show = function () {
        this.imageUploadModal.show();
    };
    ComplibImageCropComponent.prototype.cropped = function (bounds) {
        this.croppedHeight = bounds.bottom - bounds.top;
        this.croppedWidth = bounds.right - bounds.left;
    };
    ComplibImageCropComponent.prototype.fileChangeListener = function ($event) {
        var image = new Image();
        var file = $event.target.files[0];
        var myReader = new FileReader();
        var that = this;
        myReader.onloadend = function (loadEvent) {
            image.src = loadEvent.target.result;
            that.cropper.setImage(image);
        };
        myReader.onerror = function () {
            // // // // console.log('sds')
        };
        myReader.readAsDataURL(file);
    };
    ComplibImageCropComponent.prototype.getImg = function () {
        if (this.data1.image) {
            var message = this.data1.image.toString().split(',')[1];
            this.sendImage.emit(message);
            this.hideModal();
        }
        else {
            jQuery.errorMessage('upload image first');
        }
    };
    ComplibImageCropComponent.prototype.hideModal = function () {
        this.imageUploadModal.hide();
        this.onClose.emit(true);
    };
    ComplibImageCropComponent.prototype.triggerInput = function () {
        jQuery('input[type=file]').trigger('click');
    };
    return ComplibImageCropComponent;
}());
__decorate([
    core_1.ViewChild('imageUploadModal'),
    __metadata("design:type", ngx_bootstrap_1.ModalDirective)
], ComplibImageCropComponent.prototype, "imageUploadModal", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ComplibImageCropComponent.prototype, "sendImage", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], ComplibImageCropComponent.prototype, "showPopup", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.EventEmitter)
], ComplibImageCropComponent.prototype, "onClose", void 0);
__decorate([
    core_1.ViewChild('cropper', undefined),
    __metadata("design:type", ng2_img_cropper_1.ImageCropperComponent)
], ComplibImageCropComponent.prototype, "cropper", void 0);
ComplibImageCropComponent = __decorate([
    core_1.Component({
        selector: 'image-upload',
        templateUrl: 'complib-image-crop.component.html'
    }),
    __metadata("design:paramtypes", [])
], ComplibImageCropComponent);
exports.ComplibImageCropComponent = ComplibImageCropComponent;
//# sourceMappingURL=complib-image-crop.component.js.map