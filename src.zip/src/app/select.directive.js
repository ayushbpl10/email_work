"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var SelectDirective = (function () {
    function SelectDirective(el) {
        this.el = el;
        this.ngModelChangeDetect = true;
        this.disabled = false;
    }
    SelectDirective.prototype.ngAfterViewInit = function () {
        this.initialize();
    };
    SelectDirective.prototype.ngOnChanges = function (changes) {
        var _this = this;
        if (changes.select || changes.disabled) {
            setTimeout(function () {
                jQuery(_this.el.nativeElement).material_select('destroy');
                _this.initialize();
            }, 100);
        }
        if (this.ngModelChangeDetect && changes.ngModel) {
            setTimeout(function () {
                jQuery(_this.el.nativeElement).material_select('destroy');
                _this.initialize();
            }, 100);
        }
    };
    SelectDirective.prototype.initialize = function () {
        var _this = this;
        jQuery(this.el.nativeElement).material_select();
        this.el.nativeElement.onchange = function () {
            if (_this.el.nativeElement.multiple) {
                if (_this.length !== _this.el.nativeElement.selectedOptions.length) {
                    _this.length = _this.el.nativeElement.selectedOptions.length;
                    _this.event = new Event('change');
                    _this.el.nativeElement.dispatchEvent(_this.event);
                }
                else {
                    _this.event.stopPropagation();
                }
            }
            else {
                if (_this.value !== _this.el.nativeElement.value) {
                    _this.value = _this.el.nativeElement.value;
                    _this.event = new Event('change');
                    _this.el.nativeElement.dispatchEvent(_this.event);
                }
                else {
                    _this.event.stopPropagation();
                }
            }
        };
    };
    return SelectDirective;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], SelectDirective.prototype, "select", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], SelectDirective.prototype, "ngModel", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], SelectDirective.prototype, "ngModelChangeDetect", void 0);
__decorate([
    core_1.Input('disabled'),
    __metadata("design:type", Boolean)
], SelectDirective.prototype, "disabled", void 0);
SelectDirective = __decorate([
    core_1.Directive({
        selector: '[select]'
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], SelectDirective);
exports.SelectDirective = SelectDirective;
//# sourceMappingURL=select.directive.js.map