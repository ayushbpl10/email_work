"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var discountCoupon_service_1 = require("./discountCoupon.service");
var DiscountCouponListComponent = (function () {
    function DiscountCouponListComponent(discountCouponService) {
        this.discountCouponService = discountCouponService;
        this.AttachedCoupon = new core_1.EventEmitter();
        this._discountCouponList = [];
    }
    DiscountCouponListComponent.prototype.ngOnInit = function () { };
    DiscountCouponListComponent.prototype.open = function (TemplateID) {
        console.log(TemplateID);
        this._discountCouponList = this.discountCouponService.getDiscountCouponList(TemplateID);
        for (var _i = 0, _a = this._discountCouponList; _i < _a.length; _i++) {
            var _discountCoupon = _a[_i];
            var current = moment();
            var duration = moment.duration(current.diff(_discountCoupon['createdOn']));
            var mins = duration.asMinutes();
            var hours = duration.asHours();
            var days = duration.asDays();
            var months = duration.asMonths();
            var years = duration.asYears();
            if (mins < 60 && hours < 1 && days < 1 && months < 1 && years < 1) {
                _discountCoupon['createdDifference'] = 'Created ' + Math.floor(mins).toString() + ' minutes ago';
            }
            else if (mins > 60 && hours < 24 && days < 1 && months < 1 && years < 1) {
                _discountCoupon['createdDifference'] = 'Created ' + Math.floor(hours).toString() + ' hours ago';
            }
            else if (mins > 60 && hours > 24 && days < 31 && months < 1 && years < 1) {
                _discountCoupon['createdDifference'] = 'Created ' + Math.floor(days).toString() + ' days ago';
            }
            else if (mins > 60 && hours > 24 && days > 31 && months < 12 && years < 1) {
                _discountCoupon['createdDifference'] = 'Created ' + Math.floor(months).toString() + ' months ago';
            }
            else if (mins > 60 && hours > 24 && days > 31 && months > 12 && years < 200) {
                _discountCoupon['createdDifference'] = 'Created ' + Math.floor(years).toString() + ' years ago';
            }
        }
        jQuery('#CouponModal').modal('toggle');
    };
    DiscountCouponListComponent.prototype.onAttachCoupon = function (discountCoupon) {
        this.AttachedCoupon.emit(discountCoupon);
    };
    DiscountCouponListComponent.prototype.onPreviewClick = function () {
        console.log('preview clicked');
    };
    return DiscountCouponListComponent;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], DiscountCouponListComponent.prototype, "AttachedCoupon", void 0);
DiscountCouponListComponent = __decorate([
    core_1.Component({
        selector: 'discountCouponList',
        templateUrl: './discountCouponList.component.html'
    }),
    __metadata("design:paramtypes", [discountCoupon_service_1.GetDiscountCouponService])
], DiscountCouponListComponent);
exports.DiscountCouponListComponent = DiscountCouponListComponent;
//# sourceMappingURL=discountCouponList.component.js.map