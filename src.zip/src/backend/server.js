const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
 
const app = express();
app.use(cors());
 
const upload = multer({
  dest: 'G:/appointy/Task_32_edit_template_modal/Ayush_angular_html_template_New/src/backend/uploads/',
  storage: multer.diskStorage({
	  destination: function (req, file, cb) {
    cb(null, 'G:/appointy/Task_32_edit_template_modal/Ayush_angular_html_template_New/src/backend/uploads/')
  },
    filename: (req, file, cb) => {
      let ext = path.extname(file.originalname);
      cb(null, `${Math.random().toString(36).substring(7)}${ext}`);
    }
  })
});
 
app.post('/upload', upload.any(), (req, res) => {
  res.json(req.files.map(file => {
    let ext = path.extname(file.originalname);
	console.log(file)
    return {
      originalName: file.originalname,
      filename: file.filename
    }
  }));
});
 
app.listen(10050, () => {
  console.log('ng2-uploader server running on port 10050.');
});